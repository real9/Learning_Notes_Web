<template>
<div></div>
</template>

<script>
export default {
  name: "QuantitativeIndex"
}
</script>

<style scoped>

</style>
