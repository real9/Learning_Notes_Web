<template>
<div></div>
</template>

<script>
export default {
  name: "OriginalIndex"
}
</script>

<style scoped>

</style>
