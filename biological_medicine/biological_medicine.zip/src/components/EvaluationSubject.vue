<template>
<div></div>
</template>

<script>
export default {
  name: "EvaluationSubject"
}
</script>

<style scoped>

</style>
