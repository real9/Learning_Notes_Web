<template>
<div></div>
</template>

<script>
export default {
  name: "EvaluationModel"
}
</script>

<style scoped>

</style>
