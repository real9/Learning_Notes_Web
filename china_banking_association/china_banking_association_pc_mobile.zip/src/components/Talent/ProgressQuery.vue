<template>
<div>progress query</div>
</template>

<script>
export default {
  name: "ProgressQuery"
}
</script>

<style scoped>

</style>
