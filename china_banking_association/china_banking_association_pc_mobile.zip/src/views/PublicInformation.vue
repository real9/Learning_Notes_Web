<template>

</template>

<script>
export default {
  name: "PublicInformation"
}
</script>

<style scoped>

</style>
