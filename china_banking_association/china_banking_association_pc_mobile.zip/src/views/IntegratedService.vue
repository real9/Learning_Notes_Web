<template>

</template>

<script>
export default {
  name: "IntegratedService"
}
</script>

<style scoped>

</style>
